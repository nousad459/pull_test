import React, { Component } from "react";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";
import { getCookie, checkCookie } from "../utils/cookies";
import { connect } from "react-redux";
import PrivateRoute from "./privateRoute";
import LoginPage from "../components/loginPage";
import RegisterPage from "../components/registerPage";
import DashboardPage from "../components/dashboardPage";
import InputNumber from "../components/inputNumber";
import AboutUs from "../components/AboutUs";
import ContactUs from "../components/ContactUs";
import HeaderComponent from "../components/header";
import "antd/dist/antd.css";
import "./App.css";

class App extends Component {
  componentDidUpdate(prevProps) {
    console.log("update", prevProps);
  }
  render() {
    const isCookie = getCookie("token");
    // console.log("token", isCookie);
    return (
      <div>
        <BrowserRouter>
          <div>
            {!isCookie ? (
              <Switch>
                <Route path="/" exact={true} component={LoginPage} />
                <Route path="/login" component={LoginPage} />
                <Route path="/register" component={RegisterPage} />
                <PrivateRoute path="/*" />
              </Switch>
            ) : (
              <div>
                <HeaderComponent />
                <Switch>
                  <Route exact path="/" component={DashboardPage} />
                  <Route path="/epc" component={AboutUs} />
                  <Route path="/contact-us" component={ContactUs} />
                  <Route path="/show-image" component={InputNumber} />
                  <PrivateRoute
                    path="/*"
                    component={() => (
                      <div className="App" style={{ padding: "254px" }}>
                        <h2>400!!! Page not found.</h2>
                      </div>
                    )}
                  />
                </Switch>
              </div>
            )}
          </div>
        </BrowserRouter>
      </div>
    );
  }
}

const mapStateToProps = (response) => ({ response });

export default connect(mapStateToProps)(App);
