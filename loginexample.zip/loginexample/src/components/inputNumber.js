import React from "react";
import { Input, Tooltip, Row, Col, Card, Spin,Divider } from "antd";
// import imageThumbnail from 'image-thumbnail';
class NumericInput extends React.Component {

  state={
    result:""
  }
  async componentDidMount() {
    const res = await fetch("http://172.16.19.22:3012/api/getSubCategory", {
      method: "POST",
      body: JSON.stringify({ categoryId: "3", catalogId: "25" }),
      headers: { "Content-type": "application/json" },
    });
    const result = await res.json();
    console.log("hhh", result);
    this.setState({result:result.result})

   console.log("hhhhhhhh",this.state.result[0].Images[0].FilePath)
  }

  render() {
    const { value } = this.props;

    return (
      <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
        {this.state.result && this.state.result.length ? (
              this.state.result.map((data, index) => {
                return (
                  <Col xs={32} sm={16} md={8} lg={6} key={index}>
                    <br />
                    <Card
                      loading={this.state.result.length ? false : true}
                      bordered={false}
                      hoverable
                      style={{ padding: 10 }}
                      // onClick={() =>
                      //   this.viewVin(data.SubCategoryPK, data.FigureDescription)
                      // }
                    >
                      {data.Images ? (
                        <img
                          alt="example"
                          // src={data.FigureImages[0].FilePath}
                          src={  data.Images[0].FilePath}
                          style={{width:"100%"}}
                        />
                        
                      ) : (
                        ""
                      )}

                      <Divider type="horizontal" />
                      <div style={{ backgroundColor: "white" }}>
                        <a
                          // onClick={() =>
                          //   this.viewVin(
                          //     data.SubCategoryPK,
                          //     data.FigureDescription
                          //   )
                          // }
                          className="device-image-single"
                        >
                          <span className="device-img-identifier" style={{color:"#fff"}}>
                            {data.Identifier + "-"}
                            <span className="device-img-description" style={{color:"#fff"}}>
                              {data.FigureDescription}
                            </span>
                          </span>
                        </a>
                      </div>
                      <div
                        style={{
                          minHeight: "77px",
                          width: "288px",  // 348 large screen
                          // border: "2px solid red",
                          marginLeft: "-33px",
                          marginBottom: "-33px",
                          background: "#666b71",

                          marginInlineEnd: "15px",
                          marginTop: "-64px",
                        }}
                      ></div>
                    </Card>
                  </Col>
                );
              })
            ) : (
              <Spin size="large" className="empty-center" />
            )}
      </Row>
    );
  }
}

export default NumericInput;
