import React, { Component } from "react";
import { Layout, Menu, Button } from "antd";
import { LoginOutlined } from "@ant-design/icons";
import { setCookie,getCookie,checkCookie } from "../utils/cookies";
import {  Redirect } from "react-router-dom";
import { Link } from "react-router-dom";
import "./App.css";
const { Header } = Layout;

class ContactUs extends Component {
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("token", "", 1);
      window.location.href = "/";
    }
  };
  render() {
    const { location } = this.props;
    const isCookie = getCookie("token");
     console.log(">>>>.",checkCookie());
    // {isCookie ? "" : <Redirect to="/" />}
    return (
      <div className="App">
         {checkCookie() !== null ? "" : <Redirect to="/" />}
        {/* <Header>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["Information"]}
            selectedKeys={[location.pathname]}
          >
            <Menu.Item key="/dashboard">
              <Link
                to={{
                  pathname: "/dashboard",
                }}
              >
                Home
              </Link>
            </Menu.Item>
            <Menu.Item key="/epc">
              <Link
                to={{
                  pathname: "/epc",
                }}
              >
                EPC
              </Link>
            </Menu.Item>
            <Menu.Item key="/contact-us">
              <Link
                to={{
                  pathname: "/contact-us",
                }}
              >
                Contact Us
              </Link>
            </Menu.Item>
            <Button
              onClick={this.logout}
              style={{ float: "right", marginTop: "20px" }}
            >
              <LoginOutlined />
            </Button>
          </Menu>
        </Header> */}
        <header className="App-header">Contact Us</header>
      </div>
    );
  }
}

export default ContactUs;
