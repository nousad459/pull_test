import React from "react";
import { Button, Layout, Menu } from "antd";
import { connect } from "react-redux";
import { Link, Redirect, withRouter } from "react-router-dom";
import { setCookie, checkCookie } from "../utils/cookies";
import { LoginOutlined } from "@ant-design/icons";
const { Header, Content } = Layout;

class HeaderComponent extends React.Component {
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("token", "", 1);
      window.location.href = "/";
    }
  };
  render() {
    const { location } = this.props;
    console.log(">.....", this.props);
    return (
      <Layout className="layout">
        <Header>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["Information"]}
            selectedKeys={[location.pathname]}
          >
            <Menu.Item key="/">
              <Link
                to={{
                  pathname: "/",
                }}
              >
                Home
              </Link>
            </Menu.Item>
            <Menu.Item key="/epc">
              <Link
                to={{
                  pathname: "/epc",
                }}
              >
                EPC
              </Link>
            </Menu.Item>
            <Menu.Item key="/contact-us">
              <Link
                to={{
                  pathname: "/contact-us",
                }}
              >
                Contact Us
              </Link>
            </Menu.Item>
            <Button
              onClick={this.logout}
              style={{ float: "right", marginTop: "20px" }}
            >
              <LoginOutlined />
            </Button>
          </Menu>
        </Header>
      </Layout>
    );
  }
}
// const mapStateToProps = (state) => {
//   return { data: state.data };
// };

// const mapDispatchToProps = (dispatch) =>
//   bindActionCreators({ requestApiData }, dispatch);
export default withRouter(HeaderComponent);
