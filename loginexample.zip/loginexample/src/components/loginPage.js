import React, { Component } from "react";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";

import "./login.css";
import { loginUserAction } from "../actions/authenticationActions";
import { setCookie } from "../utils/cookies";

class LoginPage extends Component {
  onHandleLogin = (event) => {
    event.preventDefault();

    let email = event.target.email.value;
    let password = event.target.password.value;

    const data = {
      email,
      password,
    };

    this.props.dispatch(loginUserAction(data));
  };

  componentDidMount() {
    document.title = "React Login";
  }

  render() {
    let isSuccess, message;
     console.log("ddd", this.props);
    if (this.props.response.login.hasOwnProperty("response")) {
      isSuccess = this.props.response.login.response.success;
      message = this.props.response.login.response.message;

      // if (isSuccess) {
      // setCookie(
      //   "token",
      //   this.props.response.login.response.response.token,
      //   1
      // );
      // }
    }

    return (
      <div className="container">
        <div class="wrapper">
          <div class="title">Login Form</div>
          {!isSuccess ? <div>{message}</div> : <Redirect to="/" />}
          <form onSubmit={this.onHandleLogin}>
            <div class="field">
              <input type="text" name="email" id="email" required />
              <label>Email Address</label>
            </div>
            <div class="field">
              <input type="password" name="password" id="password" required />
              <label>Password</label>
            </div>
            <div class="content">
              <div class="checkbox">
                <input type="checkbox" id="remember-me" />
                <label for="remember-me">Remember me</label>
              </div>
              <div class="pass-link">
                <a href="#">Forgot password?</a>
              </div>
            </div>
            <div class="field">
              <input type="submit" value="Login" />
            </div>
            <div class="signup-link">
              Not a member? <a href="#">Signup now</a>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (response) => ({ response });

export default connect(mapStateToProps)(LoginPage);
