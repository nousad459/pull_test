import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import {
  Form,
  Input,
  Row,
  Col,
  Checkbox,
  Button,
  PageHeader,
  Spin,
  Card,
} from "antd";
import "./login.css";
import { loginUserAction } from "../actions/authenticationActions";
import { setCookie } from "../utils/cookies";

class LoginPage extends Component {
  onHandleLogin = (event) => {
    event.preventDefault();

    let email = event.target.email.value;
    let password = event.target.password.value;

    const data = {
      email,
      password,
    };

    this.props.dispatch(loginUserAction(data));
  };

  componentDidMount() {
    document.title = "React Login";
  }

  render() {
    let isSuccess, message;

    if (this.props.response.login.hasOwnProperty("response")) {
      isSuccess = this.props.response.login.response.success;
      message = this.props.response.login.response.message;

      if (isSuccess) {
        // setCookie(
        //   "token",
        //   this.props.response.login.response.response.token,
        //   1
        // );
        // this.props.history.push("/dashboard");
      }
    }
    console.log("token",this.props);
    return (
      // <Row
      //   type="flex"
      //   justify="center"
      //   align="middle"
      //   style={{ minHeight: "70vh" }}
      // >
      //   <Col span={14}>
      //     <div className="Login">
      //       <h3>Login Page</h3>
      //       {!isSuccess ? <div>{message}</div> : <Redirect to="dashboard" />}
      //       <form onSubmit={this.onHandleLogin}>
      //         <div>
      //           <table>
      //             <tr>
      //               <td>
      //                 <label htmlFor="email">Email&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
      //               </td>
      //               <td>
      //                 <input type="email" name="email" id="email" />
      //               </td>
      //             </tr>
      //           </table>
      //         </div>
      //         <div>
      //           <table>
      //             <tr>
      //               <td>
      //                 <label htmlFor="password">Password</label>
      //               </td>
      //               <td>
      //                 <input type="password" name="password" id="password" />
      //               </td>
      //             </tr>
      //           </table>
      //         </div>
      //         <div>
      //           <button>Login</button>
      //         </div>
      //       </form>
      //       Don't have account? <Link to="register">Register here</Link>
      //     </div>
      //   </Col>
      // </Row>
      <div className="container">
      <div class="wrapper">
        <div class="title">Login Form</div>
        {!isSuccess ? <div>{message}</div> : <Redirect to="dashboard" />}
        <form onSubmit={this.onHandleLogin}>
          <div class="field">
            <input type="text" name="email" id="email" required />
            <label>Email Address</label>
          </div>
          <div class="field">
            <input type="password" name="password" id="password" required />
            <label>Password</label>
          </div>
          <div class="content">
            <div class="checkbox">
              <input type="checkbox" id="remember-me" />
              <label for="remember-me">Remember me</label>
            </div>
            <div class="pass-link">
              <a href="#">Forgot password?</a>
            </div>
          </div>
          <div class="field">
            <input type="submit" value="Login" />
          </div>
          <div class="signup-link">
            Not a member? <a href="#">Signup now</a>
          </div>
        </form>
      </div>
      </div>
    );
  }
}

const mapStateToProps = (response) => ({ response });

export default connect(mapStateToProps)(LoginPage);
