import { setCookie } from "../utils/cookies";

export const registerUserService = (request) => {
  const REGISTER_API_ENDPOINT = "https://reqres.in/api/register";

  const parameters = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request.user),
  };

  return fetch(REGISTER_API_ENDPOINT, parameters)
    .then((response) => {
      if (!response.ok) {
        //throw Error(response.json());
        return response.json();
      }
      return response.json();
    })
    .then((res) => {
      if (res.error === "Note: Only defined users succeed registration") {
        return { success: false, message: res.error, response: res };
      }

      return {
        success: true,
        message: "Registration Successful",
        response: res,
      };
    })
    .catch((error) => {
      return {
        success: false,
        message: "Registration failed due to api problem",
        response: error,
      };
    });
};

export const loginUserService = (request) => {
  const LOGIN_API_ENDPOINT = "https://reqres.in/api/login";

  const parameters = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request.user),
  };

  return fetch(LOGIN_API_ENDPOINT, parameters)
    .then((response) => {
      if (!response.ok) {
        //throw Error(response.json());
        return response.json();
      }
      return response.json();
    })
    .then((res) => {
      if (res.error === "user not found") {
        return { success: false, message: res.error, response: res };
      }else{
        // console.log("res",res)
          setCookie("token", res.token, 1);
      }

      return { success: true, message: "Login Successful", response: res };
    })
    .catch((error) => {
      return {
        success: false,
        message: "login failed due to api problem",
        response: error,
      };
    });
};
